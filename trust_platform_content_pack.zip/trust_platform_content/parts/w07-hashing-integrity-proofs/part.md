---
id: w07-hashing-integrity-proofs
week: 7
arc: arc-2-hardening
title: "Hashing & Integrity Proofs"
order: 7
description: "**🎯 Theme:** Tamper detection starts with digest correctness."
quest_id: "w07-hashing-integrity-proofs-quest"
---

# Hashing & Integrity Proofs

**🎯 Theme:** Tamper detection starts with digest correctness.

## Structure
- **Lessons (Mon–Fri):** micro-skills with proofs
- **Quest (Sat):** integration “boss fight” that composes everything

## Quality gate
Pass the Quest proof and attach evidence (logs/tests/screenshots).
