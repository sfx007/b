---
id: w03-multi-client-event-loop
week: 3
arc: arc-1-foundations
title: "Multi-Client Event Loop"
order: 3
description: "**🎯 Theme:** `select`/`poll` — concurrency without threads."
quest_id: "w03-multi-client-event-loop-quest"
---

# Multi-Client Event Loop

**🎯 Theme:** `select`/`poll` — concurrency without threads.

## Structure
- **Lessons (Mon–Fri):** micro-skills with proofs
- **Quest (Sat):** integration “boss fight” that composes everything

## Quality gate
Pass the Quest proof and attach evidence (logs/tests/screenshots).
