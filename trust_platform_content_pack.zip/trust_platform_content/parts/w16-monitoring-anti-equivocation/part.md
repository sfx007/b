---
id: w16-monitoring-anti-equivocation
week: 16
arc: arc-4-trust-architecture
title: "Monitoring & Anti-Equivocation"
order: 16
description: "**🆕 New skill:** Monitor gossip and incident response **🔄 Reinforcement:** Checkpoints/proofs/signature verification"
quest_id: "w16-monitoring-anti-equivocation-quest"
---

# Monitoring & Anti-Equivocation

**🆕 New skill:** Monitor gossip and incident response **🔄 Reinforcement:** Checkpoints/proofs/signature verification

## Structure
- **Lessons (Mon–Fri):** micro-skills with proofs
- **Quest (Sat):** integration “boss fight” that composes everything

## Quality gate
Pass the Quest proof and attach evidence (logs/tests/screenshots).
