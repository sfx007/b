---
id: w22-security-threat-model-story
week: 22
arc: arc-6-ship-it
title: "Security / Threat Model Story"
order: 22
description: ""
quest_id: "w22-security-threat-model-story-quest"
---

# Security / Threat Model Story



## Structure
- **Lessons (Mon–Fri):** micro-skills with proofs
- **Quest (Sat):** integration “boss fight” that composes everything

## Quality gate
Pass the Quest proof and attach evidence (logs/tests/screenshots).
