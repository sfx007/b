---
id: w04-epoll-http-client
week: 4
arc: arc-1-foundations
title: "Epoll & HTTP Client"
order: 4
description: "**🎯 Theme:** Connect socket mechanics to real protocol interactions."
quest_id: "w04-epoll-http-client-quest"
---

# Epoll & HTTP Client

**🎯 Theme:** Connect socket mechanics to real protocol interactions.

## Structure
- **Lessons (Mon–Fri):** micro-skills with proofs
- **Quest (Sat):** integration “boss fight” that composes everything

## Quality gate
Pass the Quest proof and attach evidence (logs/tests/screenshots).
