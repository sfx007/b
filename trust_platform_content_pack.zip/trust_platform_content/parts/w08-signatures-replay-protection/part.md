---
id: w08-signatures-replay-protection
week: 8
arc: arc-2-hardening
title: "Signatures & Replay Protection"
order: 8
description: "**🎯 Theme:** Identity and anti-replay are core trust-system primitives."
quest_id: "w08-signatures-replay-protection-quest"
---

# Signatures & Replay Protection

**🎯 Theme:** Identity and anti-replay are core trust-system primitives.

## Structure
- **Lessons (Mon–Fri):** micro-skills with proofs
- **Quest (Sat):** integration “boss fight” that composes everything

## Quality gate
Pass the Quest proof and attach evidence (logs/tests/screenshots).
