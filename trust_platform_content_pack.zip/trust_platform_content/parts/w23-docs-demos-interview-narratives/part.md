---
id: w23-docs-demos-interview-narratives
week: 23
arc: arc-6-ship-it
title: "Docs, Demos & Interview Narratives"
order: 23
description: ""
quest_id: "w23-docs-demos-interview-narratives-quest"
---

# Docs, Demos & Interview Narratives



## Structure
- **Lessons (Mon–Fri):** micro-skills with proofs
- **Quest (Sat):** integration “boss fight” that composes everything

## Quality gate
Pass the Quest proof and attach evidence (logs/tests/screenshots).
