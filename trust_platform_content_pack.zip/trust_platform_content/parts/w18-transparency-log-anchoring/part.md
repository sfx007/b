---
id: w18-transparency-log-anchoring
week: 18
arc: arc-5-civictrust-capstone
title: "Transparency Log Anchoring"
order: 18
description: ""
quest_id: "w18-transparency-log-anchoring-quest"
---

# Transparency Log Anchoring



## Structure
- **Lessons (Mon–Fri):** micro-skills with proofs
- **Quest (Sat):** integration “boss fight” that composes everything

## Quality gate
Pass the Quest proof and attach evidence (logs/tests/screenshots).
