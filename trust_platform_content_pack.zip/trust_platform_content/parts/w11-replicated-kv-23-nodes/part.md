---
id: w11-replicated-kv-23-nodes
week: 11
arc: arc-3-distributed-core
title: "Replicated KV (2–3 Nodes)"
order: 11
description: "**🆕 New skill:** Replication protocol and quorum logic **🔄 Reinforcement:** WAL ordering and signed envelopes"
quest_id: "w11-replicated-kv-23-nodes-quest"
---

# Replicated KV (2–3 Nodes)

**🆕 New skill:** Replication protocol and quorum logic **🔄 Reinforcement:** WAL ordering and signed envelopes

## Structure
- **Lessons (Mon–Fri):** micro-skills with proofs
- **Quest (Sat):** integration “boss fight” that composes everything

## Quality gate
Pass the Quest proof and attach evidence (logs/tests/screenshots).
