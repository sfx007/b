---
id: w02-tcp-echo-server-with-stream-safe-framing
week: 2
arc: arc-1-foundations
title: "TCP Echo Server with Stream-Safe Framing"
order: 2
description: "**🎯 Theme:** Shift from local file correctness to network correctness."
quest_id: "w02-tcp-echo-server-with-stream-safe-framing-quest"
---

# TCP Echo Server with Stream-Safe Framing

**🎯 Theme:** Shift from local file correctness to network correctness.

## Structure
- **Lessons (Mon–Fri):** micro-skills with proofs
- **Quest (Sat):** integration “boss fight” that composes everything

## Quality gate
Pass the Quest proof and attach evidence (logs/tests/screenshots).
