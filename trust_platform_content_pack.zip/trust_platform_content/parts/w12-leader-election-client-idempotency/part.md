---
id: w12-leader-election-client-idempotency
week: 12
arc: arc-3-distributed-core
title: "Leader Election + Client Idempotency"
order: 12
description: "**🆕 New skill:** Term-based leader election and idempotent retries **🔄 Reinforcement:** Request IDs and quorum semantics"
quest_id: "w12-leader-election-client-idempotency-quest"
---

# Leader Election + Client Idempotency

**🆕 New skill:** Term-based leader election and idempotent retries **🔄 Reinforcement:** Request IDs and quorum semantics

## Structure
- **Lessons (Mon–Fri):** micro-skills with proofs
- **Quest (Sat):** integration “boss fight” that composes everything

## Quality gate
Pass the Quest proof and attach evidence (logs/tests/screenshots).
