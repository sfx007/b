---
id: w21-reliability-slo-story
week: 21
arc: arc-6-ship-it
title: "Reliability / SLO Story"
order: 21
description: ""
quest_id: "w21-reliability-slo-story-quest"
---

# Reliability / SLO Story



## Structure
- **Lessons (Mon–Fri):** micro-skills with proofs
- **Quest (Sat):** integration “boss fight” that composes everything

## Quality gate
Pass the Quest proof and attach evidence (logs/tests/screenshots).
