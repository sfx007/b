---
id: w10-wal-durability-crash-recovery
week: 10
arc: arc-3-distributed-core
title: "WAL Durability & Crash Recovery"
order: 10
description: "**🆕 New skill:** Write-ahead logging + recovery discipline **🔄 Reinforcement:** Checksums and deterministic command model"
quest_id: "w10-wal-durability-crash-recovery-quest"
---

# WAL Durability & Crash Recovery

**🆕 New skill:** Write-ahead logging + recovery discipline **🔄 Reinforcement:** Checksums and deterministic command model

## Structure
- **Lessons (Mon–Fri):** micro-skills with proofs
- **Quest (Sat):** integration “boss fight” that composes everything

## Quality gate
Pass the Quest proof and attach evidence (logs/tests/screenshots).
