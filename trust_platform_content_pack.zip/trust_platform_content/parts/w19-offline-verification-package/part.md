---
id: w19-offline-verification-package
week: 19
arc: arc-5-civictrust-capstone
title: "Offline Verification Package"
order: 19
description: ""
quest_id: "w19-offline-verification-package-quest"
---

# Offline Verification Package



## Structure
- **Lessons (Mon–Fri):** micro-skills with proofs
- **Quest (Sat):** integration “boss fight” that composes everything

## Quality gate
Pass the Quest proof and attach evidence (logs/tests/screenshots).
