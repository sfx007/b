---
id: w19-offline-verification-package-d05-batch-verifier-rules
part: w19-offline-verification-package
title: "Batch Verifier Rules"
order: 5
duration_minutes: 20
prereqs: ["w19-offline-verification-package-d04-time-policy-modes"]
proof:
  type: "paste_or_upload"
  status: "manual_or_regex"
review_schedule_days: [1,3,7,14]
---

# Batch Verifier Rules

## Visual Model
```
[Concept Map]
(put a diagram here that explains the dataflow)
```


## Core Idea
This lesson is one step inside **Offline Verification Package (Week 19)**. Lock in one new constraint and prove it with evidence.

## The Rules
- **New constraint:** Per-document verdicts even if one bundle fails
- Keep behavior deterministic (same input → same output).
- Fail closed on malformed input (reject early, log clearly).

## Practice
- **Warmup (5–10 min):** explain the diagram in 60 seconds.
- **Core (30–60 min):** implement the smallest thing that satisfies the new constraint.
- **Edge (15–30 min):** break it on purpose and verify clean failure behavior.
- **Mini-boss (15–30 min):** create a checklist/test that catches this bug next time.

## Prove it
Attach evidence for: `week-19/day5-batch-verifier-rules.md`  
Examples: test output, log snippet, or a short “expected vs got” note.

## Self-check
- What is the *new constraint* added today?
- What failure mode does it prevent?
- What would “pass” look like in logs/tests?


