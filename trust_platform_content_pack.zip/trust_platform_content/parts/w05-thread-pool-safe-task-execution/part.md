---
id: w05-thread-pool-safe-task-execution
week: 5
arc: arc-2-hardening
title: "Thread Pool & Safe Task Execution"
order: 5
description: "**🎯 Theme:** Event loop handles I/O; thread pool handles bounded CPU work."
quest_id: "w05-thread-pool-safe-task-execution-quest"
---

# Thread Pool & Safe Task Execution

**🎯 Theme:** Event loop handles I/O; thread pool handles bounded CPU work.

## Structure
- **Lessons (Mon–Fri):** micro-skills with proofs
- **Quest (Sat):** integration “boss fight” that composes everything

## Quality gate
Pass the Quest proof and attach evidence (logs/tests/screenshots).
