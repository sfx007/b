---
id: w17-issue-signed-civic-documents
week: 17
arc: arc-5-civictrust-capstone
title: "Issue Signed Civic Documents"
order: 17
description: ""
quest_id: "w17-issue-signed-civic-documents-quest"
---

# Issue Signed Civic Documents



## Structure
- **Lessons (Mon–Fri):** micro-skills with proofs
- **Quest (Sat):** integration “boss fight” that composes everything

## Quality gate
Pass the Quest proof and attach evidence (logs/tests/screenshots).
