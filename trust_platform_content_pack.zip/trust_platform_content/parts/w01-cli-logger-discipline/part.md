---
id: w01-cli-logger-discipline
week: 1
arc: arc-1-foundations
title: "CLI & Logger Discipline"
order: 1
description: "**🎯 Theme:** Build repeatable tools and evidence capture before networking complexity."
quest_id: "w01-cli-logger-discipline-quest"
---

# CLI & Logger Discipline

**🎯 Theme:** Build repeatable tools and evidence capture before networking complexity.

## Structure
- **Lessons (Mon–Fri):** micro-skills with proofs
- **Quest (Sat):** integration “boss fight” that composes everything

## Quality gate
Pass the Quest proof and attach evidence (logs/tests/screenshots).
