---
id: w01-cli-logger-discipline-d05-quest-test-plan-design-2h
part: w01-cli-logger-discipline
title: "Quest: Test Plan Design  2h"
order: 5
duration_minutes: 20
prereqs: ["w01-cli-logger-discipline-d04-quest-error-catalog-2h"]
proof:
  type: "paste_or_upload"
  status: "manual_or_regex"
review_schedule_days: [1,3,7,14]
---

# Quest: Test Plan Design  2h

## Visual Model
```
[Concept Map]
(put a diagram here that explains the dataflow)
```


## Lesson Content
### 📖 Learn (30 min)
**Test harness planning**

Key takeaways:
1. Golden-file tests
2. Negative tests
3. Deterministic timestamps via injection plan

### 🔨 Do (80 min)
Design CLI/logger test plan.

> 🆕 **New constraint:** Deterministic output even when time is involved.

### ✅ Prove (20 min)
Define pass/fail criteria for 15 tests including malformed inputs.

### 📦 Ship
`week-1/day5-test-plan.md`

### 💡 Why This Matters
You now have explicit evidence criteria, not "it seems fine." This converts learning into measurable progress. It unlocks confidence for network-layer integration next week.

### 🧠 Self-Check
- [ ] What makes a test deterministic?
- [ ] What is a golden file?
- [ ] Why include negative tests first?

