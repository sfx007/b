---
id: w01-cli-logger-discipline-d01-quest-define-your-cli-contract-2h
part: w01-cli-logger-discipline
title: "Quest: Define Your CLI Contract  2h"
order: 1
duration_minutes: 20
prereqs: []
proof:
  type: "paste_or_upload"
  status: "manual_or_regex"
review_schedule_days: [1,3,7,14]
---

# Quest: Define Your CLI Contract  2h

## Visual Model
```
[Concept Map]
(put a diagram here that explains the dataflow)
```


## Lesson Content
### 📖 Learn (30 min)
**CLI contract design and deterministic outputs**

Key takeaways:
1. Input/output is an API
2. Exit codes are behavior
3. Stderr for errors, stdout for data

### 🔨 Do (80 min)
Define `log append/read/search` behavior and argument rules.

> 🆕 **New constraint:** Strict exit-code table for all failure modes.

### ✅ Prove (20 min)
Build a **12-case argument matrix** (valid, missing args, malformed flags).

### 📦 Ship
`week-1/day1-cli-contract.md`

### 💡 Why This Matters
This day creates your behavior spec *before* implementation. It prevents hidden ambiguity later when tests fail. It unlocks automated CLI regression checks.

### 🧠 Self-Check
- [ ] What is a command contract?
- [ ] Why are exit codes part of an API?
- [ ] Which errors must go to stderr?

