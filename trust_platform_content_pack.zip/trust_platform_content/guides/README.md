# Guides

This folder can host platform-wide docs (checkpoints, scoring, reviews).
Generated from your 24-week roadmap.
